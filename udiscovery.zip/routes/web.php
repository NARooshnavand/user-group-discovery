<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('test/{id}','TestController@getallattrs');
Route::get('detectstate','TestController@detectstate');
Route::get('agecat','TestController@agecat');
Route::get('getuserlist/{key}','TestController@getlistuserattr');
Route::get('getallvalues/{id}','TestController@getallvalues');
Route::get('checkallgroup/{id}','TestController@checkallgroup');
Route::get('showallgroup/{id}','TestController@showallgroup');
Route::get('seegenre/{genre}',function($genre){
	$items = App\Mitem::where($genre,1)->get();
	dd(count($items));
});
Route::get('exactalgorithm/{id}','TestController@exactalgorithm');
Route::get('randomalgorithm/{id}','TestController@randomalgorithm');
Route::get('mtest','GoalProgrammingController@test');
Route::get('goalexactalgorithm/{id}','GoalProgrammingController@exactalgorithm');
