<!DOCTYPE html>
<html>
<head>
	<title></title>
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>
	@php
	$page= isset($_GET['page'])? $_GET['page']:1;
	@endphp
<h1 align="center">گروههای</h1>
<table class="table table-striped" dir="rtl">
	<thead>
		<tr>
			<th  >ردیف</th>
			<th align="center">مشخصات گروه</th>
			<th >تعداد ارزیابی ها</th>
		</tr>
	</thead>
	<tbody>
	@foreach($groups as $group)

		@php
			$mgr = json_decode($group['group_attr'],true);
			$st = 'مشخصات گروه : ';
			
			array_key_exists('gender',$mgr)? $st.='جنسیت : '.$mgr['gender']:null;
			array_key_exists('age',$mgr)? $st.='سن : '.$mgr['age']:null;
			array_key_exists('state',$mgr)? $st.='ایالت : '.$mgr['state']:null;
			array_key_exists('occupation',$mgr)? $st.='شغل : '.$mgr['occupation']:null;
			$rates = json_decode($group['ratings'],true);
		@endphp
		<tr>
			<td>{!! (($page-1)*15)+$loop->iteration !!}</td>
			<td>{!! $st !!}</td>
			<td>{!! count($rates)!!}</td>
		</tr>
	@endforeach
	</tbody>
</table>
{!!$groups->links()!!}
</body>
</html>