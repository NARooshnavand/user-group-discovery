<?php

namespace App\Http\Controllers;
use App\Muser;
use App\Mitem;
use App\Mdata;
use GuzzleHttp\Client as HttpClient;
use App\iGroups;
use App\Optimalgroups;

class TestController extends Controller
{
    public function getallattrs($id)
    {
        $mdatas = Mdata::where('item_id',$id)->get();
        dd($mdatas);
    }
    public function detectstate()
    {
    	$musers = Muser::where('state','=',null)->get();
    	foreach ($musers as $muser) {
            $endpoint = "http://api.zippopotam.us/us/".$muser->zipcode;

            $content = @file_get_contents($endpoint);
            
            if($content==false)
            {
                $muser->state = 'N-';

            }else{
                $content = json_decode($content,true);
            $muser->state = $content['places'][0]['state abbreviation'];

            }
            
            $muser->save();
    	}
    }
    public function agecat(){
    	$musers = Muser::all();
    	foreach ($musers as $user) {
    		if($user->age<18)
    		{
    			$user->mage = 'Teen';
    			$user->save();
    		}elseif($user->age>=18 && $user->age<35)
    		{
    			$user->mage = 'Young';
    			$user->save();
    		}elseif($user->age>=35 && $user->age<55)
    		{
    			$user->mage = 'Middle';
    			$user->save();
    		}elseif($user->age>=55)
    		{
    			$user->mage = 'Old';
    			$user->save();
    		}
    	}
    }
    public function getlistuserattr($key)
    {
        $users = Muser::all()->keyBy($key);
        dd($users);
    }
    public function getallvalues($id)
    {
        $datas = Mdata::where('item_id',$id)->get();
        $states = array();
        $genders = array();
        $occupations = array();
        $ages = array();
        foreach ($datas as $data) {
            $user = $data->user;
            if(!in_array($user->state, $states))
                $states[] = $user->state;
            if(!in_array($user->gender, $genders))
                $genders[] = $user->gender;
            if(!in_array($user->occupation, $occupations))
                $occupations[] = $user->occupation;
            if(!in_array($user->mage, $ages))
                $ages[] = $user->mage;
        }
        $st = 'Number of states : '.count($states).' Number of genders : '.count($genders).' Number of Occupations : '.count($occupations). ' Number of ages: '. count($ages);
        dd($st);
        
    }
    public function checkallgroup($id)
    {
        $datas = Mdata::where('item_id',$id)->get();
        $states = array();
        $genders = array();
        $occupations = array();
        $ages = array();
        foreach ($datas as $data) {
            $user = $data->user;
            if(!in_array($user->state, $states))
                $states[] = $user->state;
            if(!in_array($user->gender, $genders))
                $genders[] = $user->gender;
            if(!in_array($user->occupation, $occupations))
                $occupations[] = $user->occupation;
            if(!in_array($user->mage, $ages))
                $ages[] = $user->mage;
        }
        $Groups = array();
        //select each 4 items
        foreach ($states as $state) {
            foreach ($occupations as $occupation) {
                foreach ($ages as $age) {
                    foreach ($genders as $gender) {
                        $a = $this->getinsidedatas($datas,$gender,$age,$occupation,$state);
                        if(count($a)!=0)
                        {
                            $Groups[] = ['state'=>$state,'occupation'=>$occupation,'age'=>$age,'gender'=>$gender,'ratings'=>$a['ratings'],'users'=>$a['user']];
                        }
                    }
                }
            }
        }
        //select 3 item
        foreach ($occupations as $occupation) {
            foreach ($ages as $age) {
                foreach ($genders as $gender) {
                    $a = $this->getinsidedatas($datas,$gender,$age,$occupation);
                    if(count($a)!=0)
                    {
                        $Groups[] = ['occupation'=>$occupation,'age'=>$age,'gender'=>$gender,'ratings'=>$a['ratings'],'users'=>$a['user']];
                    }
                }
            }
        }
        foreach ($states as $state) {
            foreach ($ages as $age) {
                foreach ($genders as $gender) {
                    $a = $this->getinsidedatas($datas,$gender,$age,null,$state);
                    if(count($a)!=0)
                    {
                        $Groups[] = ['state'=>$state,'age'=>$age,'gender'=>$gender,'ratings'=>$a['ratings'],'users'=>$a['user']];
                    }
                }
            }
        }
        foreach ($states as $state) {
            foreach ($occupations as $occupation) {
                foreach ($genders as $gender) {
                    $a = $this->getinsidedatas($datas,$gender,null,$occupation,$state);
                    if(count($a)!=0)
                    {
                        $Groups[] = ['state'=>$state,'occupation'=>$occupation,'gender'=>$gender,'ratings'=>$a['ratings'],'users'=>$a['user']];
                    }
                }
            }
        }
        foreach ($states as $state) {
            foreach ($occupations as $occupation) {
                foreach ($ages as $age) {
                    $a = $this->getinsidedatas($datas,null,$age,$occupation,$state);
                    if(count($a)!=0)
                    {
                        $Groups[] = ['state'=>$state,'occupation'=>$occupation,'age'=>$age,'ratings'=>$a['ratings'],'users'=>$a['user']];
                    }
                }
            }
        }
        //Select 2 items
        foreach ($ages as $age) {
            foreach ($genders as $gender) {
                $a = $this->getinsidedatas($datas,$gender,$age);
                if(count($a)!=0)
                {
                    $Groups[] = ['age'=>$age,'gender'=>$gender,'ratings'=>$a['ratings'],'users'=>$a['user']];
                }
            }
        }
        foreach ($ages as $age) {
            foreach ($states as $state) {
                $a = $this->getinsidedatas($datas,null,$age,null,$state);
                if(count($a)!=0)
                {
                    $Groups[] = ['age'=>$age,'state'=>$state,'ratings'=>$a['ratings'],'users'=>$a['user']];
                }
            }
        }
        foreach ($ages as $age) {
            foreach ($occupations as $occupation) {
                $a = $this->getinsidedatas($datas,null,$age,$occupation);
                if(count($a)!=0)
                {
                    $Groups[] = ['age'=>$age,'occupation'=>$occupation,'ratings'=>$a['ratings'],'users'=>$a['user']];
                }
            }
        }
        foreach ($states as $state) {
            foreach ($genders as $gender) {
                $a = $this->getinsidedatas($datas,$gender,null,null,$state);
                if(count($a)!=0)
                {
                    $Groups[] = ['state'=>$state,'gender'=>$gender,'ratings'=>$a['ratings'],'users'=>$a['user']];
                }
            }
        }
        foreach ($occupations as $occupation) {
            foreach ($genders as $gender) {
                $a = $this->getinsidedatas($datas,$gender,null,$occupation);
                if(count($a)!=0)
                {
                    $Groups[] = ['occupation'=>$occupation,'gender'=>$gender,'ratings'=>$a['ratings'],'users'=>$a['user']];
                }
            }
        }
        foreach ($occupations as $occupation) {
            foreach ($states as $state) {
                $a = $this->getinsidedatas($datas,null,null,$occupation,$state);
                if(count($a)!=0)
                {
                    $Groups[] = ['occupation'=>$occupation,'state'=>$state,'ratings'=>$a['ratings'],'users'=>$a['user']];
                }
            }
        }
        //
        foreach ($genders as $gender) {
            $a = $this->getinsidedatas($datas,$gender);
            if(count($a)!=0)
            {
                $Groups[] = ['gender'=>$gender,'ratings'=>$a['ratings'],'users'=>$a['user']];
            }
        }
        foreach ($occupations as $occupation) {
            $a = $this->getinsidedatas($datas,null,null,$occupation);
            if(count($a)!=0)
            {
                $Groups[] = ['occupation'=>$occupation,'ratings'=>$a['ratings'],'users'=>$a['user']];
            }
        }
        foreach ($states as $state) {
            $a = $this->getinsidedatas($datas,null,null,null,$state);
            if(count($a)!=0)
            {
                $Groups[] = ['state'=>$state,'ratings'=>$a['ratings'],'users'=>$a['user']];
            }
        }
        foreach ($ages as $age) {
            $a = $this->getinsidedatas($datas,null,$age);
            if(count($a)!=0)
            {
                $Groups[] = ['age'=>$age,'ratings'=>$a['ratings'],'users'=>$a['user']];
            }
        }
        foreach ($Groups as $group) {
            $marr = array();
            if(array_key_exists('age',$group))
                $marr['age'] = $group['age'];
            if(array_key_exists('occupation',$group))
                $marr['occupation'] = $group['occupation'];
            if(array_key_exists('gender',$group))
                $marr['gender'] = $group['gender'];
            if(array_key_exists('state',$group))
                $marr['state'] = $group['state'];
            iGroups::create(['item_id'=>$id,'group_attr'=>json_encode($marr),'ratings'=>json_encode($group['ratings']),'users'=>json_encode($group['users']),'count_rates'=>count($group['ratings'])]);
        }
        return redirect('showallgroup/'.$id);
        
    }
    public function showallgroup($id)
    {
        $groups = iGroups::where('item_id',$id)->orderBy('count_rates','desc')->paginate(15);
        return view('showgroups',compact('groups'));
    }
    public function getinsidedatas($datas,$gender=null,$age=null,$occupation=null,$state=null)
    {
        $a = array();
        $check = array();
        if($gender!=null)
            $check['gender'] = $gender;
        if($age!=null)
            $check['mage'] = $age;
        if($occupation!=null)
            $check['occupation'] = $occupation;
        if($state!=null)
            $check['state'] = $state;
        foreach ($datas as $data) {
            $user = $data->user;
            $hasin = true;
            foreach ($check as $key => $value) {
                if($user[$key]!=$value)
                    $hasin = false;
            }
            if($hasin==true)
            {
                $a['user'][]=$user;
                $a['ratings'][] = $data;
            }
        }
        return $a;
    }
    public function exactalgorithm($id)
    {
        $C = iGroups::where('item_id',$id)->get();
        $datas = Mdata::where('item_id',$id)->get();
        $n = count($C);
        $l = array();
        for($ii = 0; $ii<$n;$ii++)
        {
            for($jj=$ii+1;$jj<$n;$jj++)
            {
                $selectedgroup = array($C[$ii],$C[$jj]);
                $coverage = $this->coverage($datas,$selectedgroup);
                if($coverage>=.8)
                {
                    $mm = array();
                    $mm['groupsind'] = [$ii,$jj];
                    $mm['error'] = $this->totalerror($datas,$selectedgroup);
                    $l[]= $mm;
                    Optimalgroups::create(['item_ids'=>$C[0]->item_id,'lindex'=>json_encode($mm)]);    
                }
            }
        }
        $selected = $l[0]['groupsind'];
        $error = $l[0]['error'];
        foreach ($l as $key => $value) {
            if($value['error']<$error)
            {
                $error = $value['error'];
                $selected = $value['groupsind'];
            }
        }
        dd([$C[$selected[0]],$C[$selected[1]]]);

    }
    public function randomalgorithm($id)
    {
        $C = iGroups::where('item_id',$id)->get();
        $datas = Mdata::where('item_id',$id)->get();
        $n = count($C);
        $l = array();
        $ii = mt_rand(0,$n);
        $jj = mt_rand(0,$n);
        if($ii==$jj)
            $jj = $ii+1;
        $selectedgroup = array($C[$ii],$C[$jj]);
        $coverage = $this->coverage($datas,$selectedgroup);
        if($coverage<.8)
        {
            $selectedgroup = $this->satisfycoverage($selectedgroup,$datas,$id);
        }
        dd($selectedgroup);
        $coverage = $this->coverage($datas,$selectedgroup);
        dd($coverage);
    }
    public function satisfycoverage($C,$datas,$id)
    {
        $val = $this->coverage($datas,$C);
        $Cmax = $C;
        $valmax = $val;
        while(true)
        {
            foreach ($C as $ckey=>$c) {
                // Selct Neighbor of $c;
                $Cprime = $C;
                $group_attrs = json_decode($c->group_attr,true);
                if(count($group_attrs)>1)
                {
                    foreach ($group_attrs as $key=>$group_attr) {
                        $newarray = $group_attrs;
                        unset($newarray[$key]);
                        $newarrayjson = json_encode($newarray);
                        $cprime = iGroups::where('group_attr',$newarrayjson)->where('item_id',$id)->get();
                        if(count($cprime)>0)
                        {
                            unset($Cprime[$ckey]);
                            $Cprime[$ckey] = $cprime[0];
                            $valprime = $this->coverage($datas,$Cprime);
                            if($valprime>=.8)
                            {
                                return $Cprime;
                            }
                            if($valprime>$valmax)
                            {
                                $valmax = $valprime;
                                $Cmax = $Cprime;
                            }
                            $Cprime = $C;
                        }
                    }
                }
            }
            $C = $Cmax;
            $val = $valmax;
        }

    }
    public function totalerror($datas,$C)
    {
        $res = 0;
        foreach ($datas as $r) {
            $res += $this->error($C,$r);
        }
        return $res;
    }
    public function coverage($datas,$C)
    {
        $res = 0;
        foreach ($datas as $data) {
            foreach($C as $c)
            {
                $ratings = json_decode($c->ratings,true);
                foreach ($ratings as $rate) {
                    if($rate['id']==$data->id)
                    {
                        $res++;
                        break 2;
                    }

                }

            }
        }
        return ($res/count($datas));

    }
    public function error($C,$r)
    {
        $error = 0;        
        foreach ($C as $c) {
            $avg = 0;
            $ratings = json_decode($c->ratings,true);
            foreach ($ratings as $rate) {
                $avg+=$rate['rating'];
            }
            $avg = $avg/(count($ratings));
            $error += abs($r->rating - $avg);
        }
        $error = $error/count($C);
        return $error;
    }
}
