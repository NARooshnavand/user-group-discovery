<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\iGroups;
use App\Mdata;
use App\Optimalgroups;

class GoalProgrammingController extends Controller
{
	public function exactalgorithm($id)
    {
        $C = iGroups::where('item_id',$id)->get();
        $datas = Mdata::where('item_id',$id)->get();
        $n = count($C);
        $l = array();
        for($ii = 0; $ii<$n;$ii++)
        {
            for($jj=$ii+1;$jj<$n;$jj++)
            {
                $selectedgroup = array($C[$ii],$C[$jj]);
                $coverage = $this->coverage($datas,$selectedgroup);
                if($coverage>=.8)
                {
                    $mm = array();
                    $mm['groupsind'] = [$ii,$jj];
                    $mm['numberattrs'] = $this->numberattrs($selectedgroup);
                    $l[]= $mm;
                    Optimalgroups::create(['item_ids'=>$C[0]->item_id,'lindex'=>json_encode($mm)]);    
                }
            }
        }
        $selected = $l[0]['groupsind'];
        $na = $l[0]['numberattrs'];
        foreach ($l as $key => $value) {
            if($value['numberattrs']>$na)
            {
                $na = $value['numberattrs'];
                $selected = $value['groupsind'];
            }
        }
        dd([$C[$selected[0]],$C[$selected[1]]]);

    }
	public function coverage($datas,$C)
    {
        $res = 0;
        foreach ($datas as $data) {
            foreach($C as $c)
            {
                $ratings = json_decode($c->ratings,true);
                foreach ($ratings as $rate) {
                    if($rate['id']==$data->id)
                    {
                        $res++;
                        break 2;
                    }

                }

            }
        }
        return ($res/count($datas));

    }
    public function numberattrs($C)
    {
    	$attrs = array();
    	foreach ($C as $group) {
    		$mcattrs = json_decode($group->group_attr);
    		foreach ($mcattrs as $key=>$val) {
    			if(array_key_exists($key, $attrs))
    			{

    				if($attrs[$key]!=$val)
    				{
    					if(!is_array($attrs[$key]))
    						$attrs[$key] = [$attrs[$key]];
    					$attrs[$key] = array_merge($attrs[$key],[$val]);
    				}

    			}else{
    				$attrs[$key] = $val;
    			}
    		}
    	}
    	$cnt = 0;
    	foreach ($attrs as $value) {
    		$cnt +=count($value);
    	}
    	return $cnt;
    }
}
