<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class iGroups extends Model
{

    /**
     * @var array
     */
    public $timestamps = false;
    protected $table = 'igroups';
    protected $fillable = ['item_id','group_attr','users','ratings','count_rates'];
    

  

}
