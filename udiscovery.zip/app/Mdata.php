<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mdata extends Model
{

    /**
     * @var array
     */
    public $timestamps = false;
    protected $table = 'idata';
    protected $fillable = ['user_id','item_id','rating','timestamp'];
    public function user()
    {
    	return $this->belongsTo('App\Muser','user_id');
    }

  

}
