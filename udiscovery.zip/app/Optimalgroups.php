<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Optimalgroups extends Model
{

    /**
     * @var array
     */
    public $timestamps = false;
    protected $table = 'optimalgroups';
    protected $fillable = ['item_ids','lindex'];
    

  

}
