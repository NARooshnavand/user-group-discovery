<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Muser extends Model
{

    /**
     * @var array
     */
    public $timestamps = false;
    protected $table = 'muser';
    protected $fillable = ['age','gender','occupation','zipcode','state','mage'];

  

}
