<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mitem extends Model
{

    /**
     * @var array
     */
    public $timestamps = false;
    protected $table = 'mitem';
    protected $fillable = ['title', 'release_date', 'video_release_date', 'IMDb_URL', 'unknown', 'Action', 'Adventure', 'Animation', 'Children', 'Comedy', 'Crime', 'Documentary', 'Drama', 'Fantasy', 'Film_Noir', 'Horror', 'Musical', 'Mystery', 'Romance', 'Sci_Fi', 'Thriller', 'War', 'Western'];
    

  

}
