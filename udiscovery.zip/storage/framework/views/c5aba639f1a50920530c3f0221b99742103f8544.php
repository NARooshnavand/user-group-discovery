<!DOCTYPE html>
<html>
<head>
	<title></title>
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>
	<?php
	$page= isset($_GET['page'])? $_GET['page']:1;
	?>
<h1 align="center">گروههای</h1>
<table class="table table-striped" dir="rtl">
	<thead>
		<tr>
			<th  >ردیف</th>
			<th align="center">مشخصات گروه</th>
			<th >تعداد ارزیابی ها</th>
		</tr>
	</thead>
	<tbody>
	<?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

		<?php
			$mgr = json_decode($group['group_attr'],true);
			$st = 'مشخصات گروه : ';
			
			array_key_exists('gender',$mgr)? $st.='جنسیت : '.$mgr['gender']:null;
			array_key_exists('age',$mgr)? $st.='سن : '.$mgr['age']:null;
			array_key_exists('state',$mgr)? $st.='ایالت : '.$mgr['state']:null;
			array_key_exists('occupation',$mgr)? $st.='شغل : '.$mgr['occupation']:null;
			$rates = json_decode($group['ratings'],true);
		?>
		<tr>
			<td><?php echo (($page-1)*15)+$loop->iteration; ?></td>
			<td><?php echo $st; ?></td>
			<td><?php echo count($rates); ?></td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<?php echo $groups->links(); ?>

</body>
</html>